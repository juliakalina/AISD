#ifndef __UTIL_H_INCLUDED__
#define __UTIL_H_INCLUDED__

char* GetStr(char* msg);

#endif /* !__UTIL_H_INCLUDED__ */